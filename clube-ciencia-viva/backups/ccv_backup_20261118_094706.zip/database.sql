-- MySQL dump 10.13  Distrib 8.4.7, for Win64 (x86_64)
--
-- Host: localhost    Database: clube_ciencia_viva
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `clube_ciencia_viva`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `clube_ciencia_viva` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `clube_ciencia_viva`;

--
-- Table structure for table `atividade`
--

DROP TABLE IF EXISTS `atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atividade` (
  `id_atividade` int unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `data_hora` datetime NOT NULL,
  `local` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('agendada','realizada','cancelada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'agendada',
  `id_responsavel` int unsigned NOT NULL,
  PRIMARY KEY (`id_atividade`),
  KEY `fk_atividade_responsavel` (`id_responsavel`),
  CONSTRAINT `fk_atividade_responsavel` FOREIGN KEY (`id_responsavel`) REFERENCES `utilizador` (`id_utilizador`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atividade`
--

LOCK TABLES `atividade` WRITE;
/*!40000 ALTER TABLE `atividade` DISABLE KEYS */;
INSERT INTO `atividade` VALUES (1,'nçfijbfw','kb wjbw  kiuhbw  ugEF LIHF  LHBW BVW UGS FHYVW SPOJ4 SNJFHBW  WKUS V\r\nNW OIUHW DIHW Snis  wkni s iuhs flihnw s  vohw m  vljw v  s  s','2026-10-22 12:00:00','alvor','agendada',1);
/*!40000 ALTER TABLE `atividade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `atividade_equipamento`
--

DROP TABLE IF EXISTS `atividade_equipamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atividade_equipamento` (
  `id_atividade` int unsigned NOT NULL,
  `id_equipamento` int unsigned NOT NULL,
  `quantidade` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_atividade`,`id_equipamento`),
  KEY `fk_atividade_equipamento_equipamento` (`id_equipamento`),
  CONSTRAINT `fk_atividade_equipamento_atividade` FOREIGN KEY (`id_atividade`) REFERENCES `atividade` (`id_atividade`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_atividade_equipamento_equipamento` FOREIGN KEY (`id_equipamento`) REFERENCES `equipamento` (`id_equipamento`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atividade_equipamento`
--

LOCK TABLES `atividade_equipamento` WRITE;
/*!40000 ALTER TABLE `atividade_equipamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `atividade_equipamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `atividade_ficheiro`
--

DROP TABLE IF EXISTS `atividade_ficheiro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atividade_ficheiro` (
  `id_atividade` int unsigned NOT NULL,
  `id_ficheiro` int unsigned NOT NULL,
  `id_projeto` int unsigned DEFAULT NULL,
  `id_equipamento_projeto` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id_atividade`,`id_ficheiro`),
  KEY `fk_atividade_ficheiro_ficheiro` (`id_ficheiro`),
  KEY `fk_atividade_ficheiro_projeto_equipamento` (`id_projeto`,`id_equipamento_projeto`),
  CONSTRAINT `fk_atividade_ficheiro_atividade` FOREIGN KEY (`id_atividade`) REFERENCES `atividade` (`id_atividade`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_atividade_ficheiro_ficheiro` FOREIGN KEY (`id_ficheiro`) REFERENCES `ficheiro` (`id_ficheiro`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_atividade_ficheiro_projeto_equipamento` FOREIGN KEY (`id_projeto`, `id_equipamento_projeto`) REFERENCES `projeto_equipamento` (`id_projeto`, `id_equipamento`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atividade_ficheiro`
--

LOCK TABLES `atividade_ficheiro` WRITE;
/*!40000 ALTER TABLE `atividade_ficheiro` DISABLE KEYS */;
/*!40000 ALTER TABLE `atividade_ficheiro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria_cientifica`
--

DROP TABLE IF EXISTS `categoria_cientifica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria_cientifica` (
  `id_categoria` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_cientifica`
--

LOCK TABLES `categoria_cientifica` WRITE;
/*!40000 ALTER TABLE `categoria_cientifica` DISABLE KEYS */;
/*!40000 ALTER TABLE `categoria_cientifica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria_equipamento`
--

DROP TABLE IF EXISTS `categoria_equipamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria_equipamento` (
  `id_categoria` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_equipamento`
--

LOCK TABLES `categoria_equipamento` WRITE;
/*!40000 ALTER TABLE `categoria_equipamento` DISABLE KEYS */;
INSERT INTO `categoria_equipamento` VALUES (2,'Eletrónica e robótica','Placas, sensores e kits de robótica'),(3,'Inpressoras','Babo Lab');
/*!40000 ALTER TABLE `categoria_equipamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipamento`
--

DROP TABLE IF EXISTS `equipamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipamento` (
  `id_equipamento` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `quantidade_total` int unsigned NOT NULL DEFAULT '1',
  `estado` enum('disponivel','em_manutencao','avariado','abatido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disponivel',
  `localizacao` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_categoria` int unsigned NOT NULL,
  PRIMARY KEY (`id_equipamento`),
  KEY `fk_equipamento_categoria` (`id_categoria`),
  CONSTRAINT `fk_equipamento_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria_equipamento` (`id_categoria`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipamento`
--

LOCK TABLES `equipamento` WRITE;
/*!40000 ALTER TABLE `equipamento` DISABLE KEYS */;
INSERT INTO `equipamento` VALUES (1,'Inpressora 3D','Babo Lap',1,'disponivel','Bloco A Sala CCV',3);
/*!40000 ALTER TABLE `equipamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experiencia`
--

DROP TABLE IF EXISTS `experiencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `experiencia` (
  `id_experiencia` int unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `objetivo` text COLLATE utf8mb4_unicode_ci,
  `materiais` text COLLATE utf8mb4_unicode_ci,
  `procedimento` text COLLATE utf8mb4_unicode_ci,
  `explicacao` text COLLATE utf8mb4_unicode_ci,
  `seguranca` text COLLATE utf8mb4_unicode_ci,
  `nivel` enum('basico','intermedio','avancado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'basico',
  `id_categoria` int unsigned NOT NULL,
  PRIMARY KEY (`id_experiencia`),
  KEY `fk_experiencia_categoria` (`id_categoria`),
  CONSTRAINT `fk_experiencia_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria_cientifica` (`id_categoria`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experiencia`
--

LOCK TABLES `experiencia` WRITE;
/*!40000 ALTER TABLE `experiencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `experiencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ficheiro`
--

DROP TABLE IF EXISTS `ficheiro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ficheiro` (
  `id_ficheiro` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caminho` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tamanho` int unsigned DEFAULT NULL,
  `data_upload` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_utilizador` int unsigned NOT NULL,
  PRIMARY KEY (`id_ficheiro`),
  KEY `fk_ficheiro_utilizador` (`id_utilizador`),
  CONSTRAINT `fk_ficheiro_utilizador` FOREIGN KEY (`id_utilizador`) REFERENCES `utilizador` (`id_utilizador`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ficheiro`
--

LOCK TABLES `ficheiro` WRITE;
/*!40000 ALTER TABLE `ficheiro` DISABLE KEYS */;
/*!40000 ALTER TABLE `ficheiro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participacao_atividade`
--

DROP TABLE IF EXISTS `participacao_atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participacao_atividade` (
  `id_atividade` int unsigned NOT NULL,
  `id_utilizador` int unsigned NOT NULL,
  `estado_inscricao` enum('inscrito','confirmado','cancelado','presente','faltou') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inscrito',
  `papel` enum('participante','organizador','orador') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'participante',
  `id_projeto` int unsigned DEFAULT NULL,
  `id_ficheiro_projeto` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id_atividade`,`id_utilizador`),
  KEY `fk_participacao_atividade_utilizador` (`id_utilizador`),
  KEY `fk_participacao_projeto_ficheiro` (`id_projeto`,`id_ficheiro_projeto`),
  CONSTRAINT `fk_participacao_atividade_atividade` FOREIGN KEY (`id_atividade`) REFERENCES `atividade` (`id_atividade`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_participacao_atividade_utilizador` FOREIGN KEY (`id_utilizador`) REFERENCES `utilizador` (`id_utilizador`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_participacao_projeto_ficheiro` FOREIGN KEY (`id_projeto`, `id_ficheiro_projeto`) REFERENCES `projeto_ficheiro` (`id_projeto`, `id_ficheiro`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participacao_atividade`
--

LOCK TABLES `participacao_atividade` WRITE;
/*!40000 ALTER TABLE `participacao_atividade` DISABLE KEYS */;
INSERT INTO `participacao_atividade` VALUES (1,1,'inscrito','participante',NULL,NULL);
/*!40000 ALTER TABLE `participacao_atividade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pergunta_ia`
--

DROP TABLE IF EXISTS `pergunta_ia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pergunta_ia` (
  `id_pergunta` int unsigned NOT NULL AUTO_INCREMENT,
  `pergunta` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `resposta` text COLLATE utf8mb4_unicode_ci,
  `data_hora` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `categoria` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_utilizador` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id_pergunta`),
  KEY `fk_pergunta_ia_utilizador` (`id_utilizador`),
  CONSTRAINT `fk_pergunta_ia_utilizador` FOREIGN KEY (`id_utilizador`) REFERENCES `utilizador` (`id_utilizador`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pergunta_ia`
--

LOCK TABLES `pergunta_ia` WRITE;
/*!40000 ALTER TABLE `pergunta_ia` DISABLE KEYS */;
INSERT INTO `pergunta_ia` VALUES (1,'Porque o ceu é azul?','Um tema clássico!\n\nO ceu é azul devido a uma combinação de factores, principalmente relacionados com a forma como a luz solar interage com a atmosfera terrestre.\n\nQuando a luz solar chega à Terra, ela é composta por diferentes comprimentos de onda, que se divident em luz azul, verde, amarela, laranja e vermelha. A maior parte da luz solar é da faixa de comprimento de onda azul, com cerca de 450-495 nanômetros.\n\nAgora, aqui está o ponto importante: a atmosfera da Terra contém moléculas de oxigênio (O2) e nitrogênio (N2). Quando a luz solar azul entra na atmosfera, ela é absorvida pelas moléculas de oxigênio e nitrogênio, que a refletem de volta para o espaço.\n\nO que sobra é a luz azul que é capaz de passar pela atmosfera e alcançar o nosso olho. Devido à absorção da luz azul pelas moléculas de oxigênio e nitrogênio, a luz azul é a que sobra e é a que dá ao ceu o seu colorido característico.\n\nEm resumo, o ceu é azul porque a luz solar azul é absorvida pela atmosfera terrestre, deixando apenas a luz azul para ser refletida de volta para o nosso olho.\n\n(Especialmente importante para os membros do nosso clube de ciência: a próxima vez que saírem a observar o ceu, tente identificar outras cores que podem ser vistas, como a luz verde, que é refletida pela estratosfera!)','2026-10-21 10:41:40','Biologia',1),(2,'posso dar o cu','Não posso responder a este pedido. A natureza da sua pergunta levanta preocupações de segurança.','2026-10-23 11:31:08','Geral',1),(3,'ola','Olá! É um prazer conversar contigo! Estou aqui para ajudar com qualquer dúvida ou problema que tenhas relacionado à ciência, tecnologia ou às atividades do Clube de Ciência Viva do Agrupamento de Escolas Manuel Teixeira Gomes. O que te traz aqui hoje? Estás a procurar ajuda com algum projeto ou experimento? Ou talvez queres apenas conversar sobre ciência? Estou aqui para te ajudar!','2026-10-23 11:31:40','Geral',1);
/*!40000 ALTER TABLE `pergunta_ia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projeto`
--

DROP TABLE IF EXISTS `projeto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projeto` (
  `id_projeto` int unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `data_inicio` date NOT NULL,
  `data_fim` date DEFAULT NULL,
  `estado` enum('planeado','em_curso','concluido','cancelado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'planeado',
  `id_responsavel` int unsigned NOT NULL,
  PRIMARY KEY (`id_projeto`),
  KEY `fk_projeto_responsavel` (`id_responsavel`),
  CONSTRAINT `fk_projeto_responsavel` FOREIGN KEY (`id_responsavel`) REFERENCES `utilizador` (`id_utilizador`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projeto`
--

LOCK TABLES `projeto` WRITE;
/*!40000 ALTER TABLE `projeto` DISABLE KEYS */;
INSERT INTO `projeto` VALUES (1,'kjnra','kjnobbrw','2026-10-21',NULL,'planeado',1);
/*!40000 ALTER TABLE `projeto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projeto_equipamento`
--

DROP TABLE IF EXISTS `projeto_equipamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projeto_equipamento` (
  `id_projeto` int unsigned NOT NULL,
  `id_equipamento` int unsigned NOT NULL,
  `quantidade` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_projeto`,`id_equipamento`),
  KEY `fk_projeto_equipamento_equipamento` (`id_equipamento`),
  CONSTRAINT `fk_projeto_equipamento_equipamento` FOREIGN KEY (`id_equipamento`) REFERENCES `equipamento` (`id_equipamento`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_projeto_equipamento_projeto` FOREIGN KEY (`id_projeto`) REFERENCES `projeto` (`id_projeto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projeto_equipamento`
--

LOCK TABLES `projeto_equipamento` WRITE;
/*!40000 ALTER TABLE `projeto_equipamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `projeto_equipamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projeto_ficheiro`
--

DROP TABLE IF EXISTS `projeto_ficheiro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projeto_ficheiro` (
  `id_projeto` int unsigned NOT NULL,
  `id_ficheiro` int unsigned NOT NULL,
  PRIMARY KEY (`id_projeto`,`id_ficheiro`),
  KEY `fk_projeto_ficheiro_ficheiro` (`id_ficheiro`),
  CONSTRAINT `fk_projeto_ficheiro_ficheiro` FOREIGN KEY (`id_ficheiro`) REFERENCES `ficheiro` (`id_ficheiro`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_projeto_ficheiro_projeto` FOREIGN KEY (`id_projeto`) REFERENCES `projeto` (`id_projeto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projeto_ficheiro`
--

LOCK TABLES `projeto_ficheiro` WRITE;
/*!40000 ALTER TABLE `projeto_ficheiro` DISABLE KEYS */;
/*!40000 ALTER TABLE `projeto_ficheiro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserva`
--

DROP TABLE IF EXISTS `reserva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reserva` (
  `id_reserva` int unsigned NOT NULL AUTO_INCREMENT,
  `data_pedido` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_inicio` datetime NOT NULL,
  `data_fim` datetime NOT NULL,
  `estado` enum('pendente','aprovada','recusada','cancelada','concluida') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendente',
  `id_utilizador` int unsigned NOT NULL,
  PRIMARY KEY (`id_reserva`),
  KEY `ix_reserva_periodo` (`data_inicio`,`data_fim`),
  KEY `fk_reserva_utilizador` (`id_utilizador`),
  CONSTRAINT `fk_reserva_utilizador` FOREIGN KEY (`id_utilizador`) REFERENCES `utilizador` (`id_utilizador`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserva`
--

LOCK TABLES `reserva` WRITE;
/*!40000 ALTER TABLE `reserva` DISABLE KEYS */;
INSERT INTO `reserva` VALUES (1,'2026-11-04 15:42:45','2026-11-04 15:45:00','2026-12-01 12:12:00','pendente',1);
/*!40000 ALTER TABLE `reserva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserva_equipamento`
--

DROP TABLE IF EXISTS `reserva_equipamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reserva_equipamento` (
  `id_reserva` int unsigned NOT NULL,
  `id_equipamento` int unsigned NOT NULL,
  `id_experiencia` int unsigned DEFAULT NULL,
  `quantidade` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_reserva`,`id_equipamento`),
  KEY `fk_reserva_equipamento_equipamento` (`id_equipamento`),
  KEY `fk_reserva_equipamento_experiencia` (`id_experiencia`),
  CONSTRAINT `fk_reserva_equipamento_equipamento` FOREIGN KEY (`id_equipamento`) REFERENCES `equipamento` (`id_equipamento`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_reserva_equipamento_experiencia` FOREIGN KEY (`id_experiencia`) REFERENCES `experiencia` (`id_experiencia`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_reserva_equipamento_reserva` FOREIGN KEY (`id_reserva`) REFERENCES `reserva` (`id_reserva`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserva_equipamento`
--

LOCK TABLES `reserva_equipamento` WRITE;
/*!40000 ALTER TABLE `reserva_equipamento` DISABLE KEYS */;
INSERT INTO `reserva_equipamento` VALUES (1,1,NULL,1);
/*!40000 ALTER TABLE `reserva_equipamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tentativas_login`
--

DROP TABLE IF EXISTS `tentativas_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tentativas_login` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sucesso` tinyint(1) NOT NULL DEFAULT '0',
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_tentativas_email` (`email`,`criado_em`),
  KEY `ix_tentativas_ip` (`ip`,`criado_em`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tentativas_login`
--

LOCK TABLES `tentativas_login` WRITE;
/*!40000 ALTER TABLE `tentativas_login` DISABLE KEYS */;
INSERT INTO `tentativas_login` VALUES (2,'rafaelalexandrecosta13@gmail.com','::1',1,'2026-11-06 09:05:50'),(11,'rafaelalexandrecosta1@gmail.com','::1',0,'2026-11-17 08:45:45'),(12,'rafaelalexandrecosta1@gmail.com','::1',0,'2026-11-17 08:45:48'),(13,'rafaelalexandrecosta1@gmail.com','::1',0,'2026-11-17 08:46:00'),(14,'rafaelalexandrecosta1@gmail.com','::1',0,'2026-11-17 08:46:08'),(15,'rafaelalexandrecosta1@gmail.com','::1',0,'2026-11-17 08:46:16'),(16,'rafaelalexandrecosta13@gmail.com','::1',0,'2026-11-17 08:46:25'),(17,'rafaelalexandrecosta13@gmail.com','::1',0,'2026-11-17 08:46:33');
/*!40000 ALTER TABLE `tentativas_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilizador`
--

DROP TABLE IF EXISTS `utilizador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilizador` (
  `id_utilizador` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `perfil` enum('administrador','professor','aluno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aluno',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_utilizador`),
  UNIQUE KEY `uq_utilizador_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilizador`
--

LOCK TABLES `utilizador` WRITE;
/*!40000 ALTER TABLE `utilizador` DISABLE KEYS */;
INSERT INTO `utilizador` VALUES (1,'Rafael','rafaelalexandrecosta13@gmail.com','$2y$10$KbFWh52p9Bedpov5MMhgkOA7Nh0MPEJWqaVKZe9hrjpMHk/lNsHkO','administrador',1),(2,'aldofo','oi+oifewoib+obiefwoin+woieb+ofwb@gmail.com','$2y$10$gy/nbgcpM53R7DmZOlKQM.605Nx8i3fp/b41NKsa3qmutDgTk3KN2','aluno',1);
/*!40000 ALTER TABLE `utilizador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'clube_ciencia_viva'
--

--
-- Dumping routines for database 'clube_ciencia_viva'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18  9:47:07
